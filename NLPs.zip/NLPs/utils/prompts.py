def get_prompt(question: str) -> str:
    return f"Answer this finance question in simple terms for a kid: {question}"