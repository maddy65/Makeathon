from transformers import pipeline
from utils.prompts import get_prompt

# Load model once
generator = pipeline('text-generation', model='gpt2')

def generate_answer(user_question: str) -> str:
    prompt = get_prompt(user_question)
    result = generator(prompt, max_length=100, num_return_sequences=1)
    answer = result[0]['generated_text'].replace(prompt, '').strip()
    return answer