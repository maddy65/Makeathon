from fastapi import APIRouter
from pydantic import BaseModel
from model.generator import generate_answer

router = APIRouter()

class Query(BaseModel):
    question: str

@router.post("/ask")
async def ask_question(query: Query):
    answer = generate_answer(query.question)
    return {"answer": answer}