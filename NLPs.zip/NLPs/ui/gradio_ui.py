import gradio as gr
from model.generator import generate_answer

def gradio_chat(user_input):
    return generate_answer(user_input)

def launch_gradio():
    gr.Interface(
        fn=gradio_chat, 
        inputs="text", 
        outputs="text", 
        title="Finance Chatbot for Kids"
    ).launch()